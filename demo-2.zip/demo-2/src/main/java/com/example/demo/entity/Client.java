package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
public class Client {

    @Id
    
    private int id;

    private String cname;
    private String clientCompany;
    private String cemail;
    private String cmobile;
    private String password;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return cname;
	}
	public void setName(String cname) {
		this.cname = cname;
	}
	public String getClientCompany() {
		return clientCompany;
	}
	public void setClientCompany(String clientCompany) {
		this.clientCompany = clientCompany;
	}
	public String getEmail() {
		return cemail;
	}
	public void setEmail(String cemail) {
		this.cemail = cemail;
	}
	public String getMobile() {
		return cmobile;
	}
	public void setMobile(String cmobile) {
		this.cmobile = cmobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
    
}