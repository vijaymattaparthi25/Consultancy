package com.example.demo.controller;




import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Client;
import com.example.demo.entity.Student;
import com.example.demo.repo.ClientRepository;
import com.example.demo.repo.RegisterRepo;
import com.example.demo.repo.StudentRepository;


@Controller
public class HomeController
{
	
	 @Autowired
	    private StudentRepository studentRepo;

	    @Autowired
	    private ClientRepository clientRepo;

	    
	
	@Autowired
    private RegisterRepo registerRepo;
	
	@GetMapping("/home")
	public String home()
	{
		return "home";
	}
	
	@GetMapping("/whyweare")
	public String Whyweare()
	{
		return "whyweare";
	}
	
	@GetMapping("/whatwedo")
	public String Whatwedo()
	{
		return "whatwedo";
	}
	
	@GetMapping("/workwithus")
	public String Workwithus()
	{
		return "workwithus";
	}
	
	@GetMapping("/platformNsolutions")
	public String PlatformNsolutions()
	{
		return "platformNsolutions";
	}
	
	@GetMapping("/screg")
    public String consultantRegistration() {
        return "screg"; // JSP page: screg.jsp
    }

    @GetMapping("/sereg")
    public String trainingRegistration() {
        return "sereg";
    }

    @GetMapping("/soreg")
    public String eventsRegistration() {
        return "soreg";
    }
	
	@GetMapping("/industries")
    public String industries()
    {
	return "industries";
    }

	//@GetMapping("/careers")
	//public String careers()
	//{
	//	return "careers";
	//}

	@GetMapping("/service")
    public String service()
    {
	
	return "service";
    }

	@GetMapping("/products")
    public String products()
    {
	return "products";
    }

	@GetMapping("/aboutus")
    public String aboutus()
    {
	
	return "aboutus";
    }

	@GetMapping("/contact")
    public String contact()
    {
	
	return "contact";
    }
	
	

	@GetMapping("/updatereg")
    public String Update()
    {
	return "updatereg";
    }

	@GetMapping("/reg")
    public String reg()
    {
	return "reg";
    }
	
	@GetMapping("/update1")
    public String update1()
    {
	return "update1";
    }
	
	@GetMapping("/deletereg1")
    public String deletereg1()
    {
	return "deletereg1";
    }
	
	@PostMapping("/screg")
    public String register(
            @RequestParam String userType,
            Integer id,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String mobile,

            @RequestParam(required = false) String cname,
            @RequestParam(required = false) String clientCompany,
            @RequestParam(required = false) String cemail,
            @RequestParam(required = false) String cmobile,

            @RequestParam String password,
            Model m
    ) {

        if ("student".equalsIgnoreCase(userType)) {
            Student student = new Student();
            student.setId(id);
            student.setName(name);
            student.setEmail(email);
            student.setMobile(mobile);
            student.setPassword(password);
            studentRepo.save(student);

            m.addAttribute("user", student);
            m.addAttribute("type", "Student");

        } else if ("client".equalsIgnoreCase(userType)) {
            Client client = new Client();
            client.setId(id);
            client.setName(cname);
            client.setClientCompany(clientCompany);
            client.setEmail(cemail);
            client.setMobile(cmobile);
            client.setPassword(password);
            clientRepo.save(client);

            m.addAttribute("user", client);
            m.addAttribute("type", "Client");
        }

        return "result";
    }
	
	
	
	
	@PostMapping("/update1")
    public String update1(
            @RequestParam String userType,
            @RequestParam Integer id,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String mobile,

            @RequestParam(required = false) String cname,
            @RequestParam(required = false) String clientCompany,
            @RequestParam(required = false) String cemail,
            @RequestParam(required = false) String cmobile,

            @RequestParam String password,
            Model m
    ) {

        if ("student".equalsIgnoreCase(userType)) {
        	Optional<Student> optionalStudent = studentRepo.findById(id);
            if (optionalStudent.isPresent()) {
                Student student = optionalStudent.get();

            student.setName(name);
            student.setEmail(email);
            student.setMobile(mobile);
            student.setPassword(password);
            studentRepo.save(student);

            m.addAttribute("user", student);
            m.addAttribute("type", "Student");
            
            } else {
                m.addAttribute("error", "Student not found with ID: " + id);
                return "error";
            }

        } else if ("client".equalsIgnoreCase(userType)) {
        	 Optional<Client> optionalClient = clientRepo.findById(id);
             if (optionalClient.isPresent()) {
                 Client client = optionalClient.get();
            client.setName(cname);
            client.setClientCompany(clientCompany);
            client.setEmail(cemail);
            client.setMobile(cmobile);
            client.setPassword(password);
            clientRepo.save(client);

            m.addAttribute("user", client);
            m.addAttribute("type", "Client");
             } else {
                 m.addAttribute("error", "Client not found with ID: " + id);
                 return "error";
             }
        }

        return "result";
    }
	
	
	//Delete User Record.....
	
	@PostMapping("/deletereg1")
	public String deleteUserFromForm(
	        @RequestParam String userType,
	        @RequestParam Integer id,
	        Model m) {

	    if ("student".equalsIgnoreCase(userType)) {
	        if (studentRepo.existsById(id)) {
	            studentRepo.deleteById(id);
	            m.addAttribute("message", "Student deleted successfully.");
	        } else {
	            m.addAttribute("message", "Student ID not found.");
	        }

	    } else if ("client".equalsIgnoreCase(userType)) {
	        if (clientRepo.existsById(id)) {
	            clientRepo.deleteById(id);
	            m.addAttribute("message", "Client deleted successfully.");
	        } else {
	            m.addAttribute("message", "Client ID not found.");
	        }

	    } else {
	        m.addAttribute("message", "Invalid user type.");
	    }

	    return "deleteregssuccess"; 
	}




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

@PostMapping("/reg")
public String register( Integer stdid,
		@RequestParam String fullname,
		@RequestParam String email,
		@RequestParam String username,
		@RequestParam String password,
		Model m)
		
{
	Register std1 = new Register();
	
	std1.setStdid(stdid);
    std1.setFullname(fullname);
    std1.setEmail(email);
    std1.setUsername(username);
    std1.setPassword(password);
    
    registerRepo.save(std1);
    m.addAttribute("student", std1);
	return "result";
	}

@PostMapping("/updatereg")
public String edit(
    @RequestParam int stdid,
    @RequestParam String fullname,
    @RequestParam String email,
    @RequestParam String username,
    @RequestParam String password,
    Model m) {
    
    Optional<Register> optional = registerRepo.findById(stdid);
    
    if (optional.isPresent()) {
        Register std1 = optional.get();
        std1.setFullname(fullname);
        std1.setEmail(email);
        std1.setUsername(username);
        std1.setPassword(password);

        registerRepo.save(std1);
        m.addAttribute("student", std1);
        return "result";
    } else {
        m.addAttribute("error", "Student ID not found.");
        return "error";  // Create error.jsp to handle this case
    }
}

}

