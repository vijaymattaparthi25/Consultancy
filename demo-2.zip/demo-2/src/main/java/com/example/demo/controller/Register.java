package com.example.demo.controller;

import jakarta.persistence.*;

@Entity
public class Register
{
	@Id
	@Column(name="stdid")
	private int stdid;
	
	@Column(name="fullname")
	private String fullname;
	
	@Column(name="email")
	private String email;
	
	@Column(name="username")
	private String username;
	
	@Column(name="password")
	private String password;

	//Getters and setters
	
	public int getStdid() {
		return stdid;
	}
	
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}